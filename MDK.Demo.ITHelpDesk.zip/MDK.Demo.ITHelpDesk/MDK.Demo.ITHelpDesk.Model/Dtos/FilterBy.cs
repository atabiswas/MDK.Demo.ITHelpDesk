﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MDK.Demo.ITHelpDesk.Model.Dtos
{
    public class FilterBy
    {
        public TicketStatus Status { get; set; }
        public int? AssignedUserId { get; set; }
        public int? CreatedUserId { get; set; }
    }
}
