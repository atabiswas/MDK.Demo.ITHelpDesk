﻿using MDK.Demo.ITHelpDesk.Model.Dtos;

namespace MDK.Demo.ITHelpDesk.Service.Client
{
    public class TicketService(HttpClient http)
    {
        private readonly HttpClient _http = http;

        public async Task<List<TicketInfo>> GetTicketsAsync() =>
            await _http.GetFromJsonAsync<List<TicketInfo>>("Ticket/All") ?? [];

        public async Task<List<TicketInfo>> GetTicketsFilterByAsync(FilterBy filterBy)
        {
            var url = $"Ticket/FilterBy?status={(int)filterBy.Status}&assignedUserId={filterBy.AssignedUserId}&createdUserId={filterBy.CreatedUserId}";
            return await _http.GetFromJsonAsync<List<TicketInfo>>(url) ?? [];
        }

        public async Task<List<UserInfo>> GetUsersAsync() =>
            await _http.GetFromJsonAsync<List<UserInfo>>("User/All") ?? [];

        public async Task<TicketInfo> GetTicketAsync(int id) =>
            await _http.GetFromJsonAsync<TicketInfo>($"Ticket/{id}") ?? new();

        public async Task CreateTicketAsync(TicketInfo ticket) =>
            await _http.PostAsJsonAsync("Ticket/Create", ticket);

        public async Task UpdateTicketAsync(TicketInfo ticket) =>
            await _http.PutAsJsonAsync($"Ticket/Update/{ticket.Id}", ticket);

        public async Task AssignTicketAsync(TicketInfo ticket, int userId) =>
            await _http.PutAsJsonAsync($"Ticket/Assign/{userId}", ticket);

        public async Task DeleteTicketAsync(int id) =>
            await _http.DeleteAsync($"Ticket/Delete/{id}");
    }
}
